# jade使用截图

标签（空格分隔）： 美启电力-平衡机器 施华

---

# 微电网竞价系统的使用截图
+ 输入截图
![4.PNG-33.9kB][1]
+ 信息交互截图
![5.PNG-34.2kB][2]


  [1]: http://static.zybuluo.com/tulip0216/xdp8az3ujgclsuwi80b0bb9t/4.PNG
  [2]: http://static.zybuluo.com/tulip0216/xljpiqu1c54vvpltfxke7hrf/5.PNG