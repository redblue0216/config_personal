# Git

标签（空格分隔）： 施华

---

# **常用命令**
```
$git config 
$git init
$git add
$git status
$git commit
$git remote
$git pull
$git push
$git clone
$git merge
$git branch
$git checkout
```




