# linux烧录rufus

标签（空格分隔）： 施华

---

[TOC]
# rufus
+ 下载镜像iso
+ U盘格式化
+ 烧录，mbr/apt,iso,缺文件就下载
+ 完成，安全退出U盘

# 安装
+ F12 bios
+ usb hdd driver
+ eg.bodhi




