# JupyterLab

标签（空格分隔）： 施华

---

# JupyterLab
+ 安装
```
$ pip install jupyterlab
```
+ 配置
```
$ jupyter-lab --generate-config
c.NotebookApp.notebook_dir = 'D:\AEwork'
```




