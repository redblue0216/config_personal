# ezhiyangOCR

标签（空格分隔）： 施华 版本(beta0.1)

---

[TOC]
# 启动
```
$gunicorn -c gun.py flask_app:app
$#测试用例可查看flask_app.py中的注释
```




