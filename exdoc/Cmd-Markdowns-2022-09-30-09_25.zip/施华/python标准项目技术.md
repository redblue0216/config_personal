# python标准项目技术

标签（空格分隔）： 施华

---

# 工作空间文档规划
+ Demo 代码开发文件夹
+ Doc 项目设计及API相关文档文件夹
+ Git 代码分发文件夹包含Doc和Packages
+ Packages 代码标准版文件夹
+ Test 代码测试脚本文件夹




