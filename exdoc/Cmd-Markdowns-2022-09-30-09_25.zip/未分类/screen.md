# screen

标签（空格分隔）： 未分类

---

[TOC]
# 常用命令
```
$# 创建
$ screen -S XXXXX
$# 查看
$ screen -ls
$# 进入
$ screen -r 1234.xxxx
$# 退出
$ ctrl + a + d
```




