# python项目离线打包

标签（空格分隔）： 施华 版本(beta0.1)

---

[TOC]
# wheel打包
+ 依赖包
```
$ pip install setuptools
$ pip install wheel
```
+ 打包
```
$ python setup.py bdist_wheel
```
+ 安装
```
$ cd dist
$ pip install xxxxxxxxxxxxxxxxx.whl
```




