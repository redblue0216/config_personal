# 客户风控模型python脚本接口说明

标签（空格分隔）： 施华

---

# **1.py脚本运行逻辑图**
![py脚本运行逻辑图.png-619.7kB][1]


  [1]: http://static.zybuluo.com/tulip0216/uqov778ribbvymywrwdbn20u/py%E8%84%9A%E6%9C%AC%E8%BF%90%E8%A1%8C%E9%80%BB%E8%BE%91%E5%9B%BE.png