# linux后台运行

标签（空格分隔）： 未分类

---

+ nohup/jobs/kill %i
+ &
+ -d




